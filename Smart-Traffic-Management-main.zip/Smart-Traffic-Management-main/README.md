# Smart Traffic Management
## This repo contains simulation code of  Smart traffic management system
Youtube video :- https://youtu.be/UGl296sXwdk

<img src="https://github.com/AdityaWadkar/Smart-Traffic-Management/assets/67093170/a357c87c-5b1f-45d2-b0e6-4d732fd6ca07">
